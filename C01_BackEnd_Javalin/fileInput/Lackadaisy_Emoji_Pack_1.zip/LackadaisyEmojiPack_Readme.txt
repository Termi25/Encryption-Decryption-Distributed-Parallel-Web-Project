Thank you for downloading the Lackadaisy Emoji Pack. Please enjoy!
The artwork contained herein is free for personal use. Create icons, emojis, emotes, avatars, and digital stickers!
Artwork sized for use with Discord, Slack, Twitch, and Telegram is included. Full resolution artwork has also been included for customization. Crop and resize the art as desired for use with other social media!

The artwork contained in this pack is not licensed for commercial use, and is not intended for resale, reproduction or redistribution.

------------------------------------

Watch the animated series at YouTube.com/LackadaisyComic
Read the comic at Lackadaisy.com
Support the production at Patreon.com/Lackadaisy
Find merch at LackadaisyShop.com

Lackadaisy Emoji Pack © 2020 Tracy J. Butler. All rights reserved.
Lackadaisy® is a registered trademark of Tracy J. Butler.
Artwork by Keith Daily
